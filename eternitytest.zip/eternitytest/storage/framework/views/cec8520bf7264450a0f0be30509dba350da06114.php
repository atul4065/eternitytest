<!DOCTYPE html>
<html>

<head>
    <title>Sales Analytics Dashboard</title>
    <script src="<?php echo e(asset('assets/chart.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset('assets/bootstrap.css')); ?>">
    <style>
        .dashboard-container {
            padding: 20px;
        }

        .sidebar {
            background-color: #333;
            color: #fff;
            height: 100vh;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            padding: 20px;
        }

        .content {
            margin-left: 270px;
            padding: 20px;
        }

        .chart-card {
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            padding: 20px;
        }
    </style>
</head>

<body>
    <div class="sidebar">
        <h3>Sales Dashboard</h3>
        <ul>
            <li><a href="#total-sales">Total Sales</a></li>
            <li><a href="#top-selling-products">Top-Selling Products</a></li>
            <li><a href="#sales-by-category">Sales by Category</a></li>
            <li><a href="#revenue-trends">Revenue Trends</a></li>
            <li><a href="#order-status">Order Status</a></li>
            <li><a href="#customer-acquisition">Customer Acquisition</a></li>
        </ul>
    </div>

    <div class="content">
        <div class="container dashboard-container">
            <h1 class="text-center mb-4">Sales Analytics Dashboard</h1>
            <div class="row">
                <div class="col-md-6">
                    <div class="card chart-card">
                        <div class="card-body">
                            <h2 class="card-title text-center">Total Sales Over Time</h2>
                            <canvas id="salesChart" width="400" height="200"></canvas>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card chart-card">
                        <div class="card-body">
                            <h2 class="card-title text-center">Top-Selling Products</h2>
                            <canvas id="topSellingProductsChart" width="400" height="200"></canvas>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="card chart-card">
                        <div class="card-body">
                            <h2 class="card-title text-center">Sales by Category</h2>
                            <canvas id="salesByCategoryChart" width="400" height="200"></canvas>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card chart-card">
                        <div class="card-body">
                            <h2 class="card-title text-center">Order Status</h2>
                            <canvas id="orderStatusChart" width="400" height="200"></canvas>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="card chart-card">
                        <div class="card-body">
                            <h2 class="card-title text-center">Revenue Trends</h2>
                            <canvas id="revenueTrendsChart" width="400" height="200"></canvas>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card chart-card">
                        <div class="card-body">
                            <h2 class="card-title text-center">Customer Acquisition</h2>
                            <canvas id="customerAcquisitionChart" width="400" height="200"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Dummy data for the charts
        var salesData = {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
            datasets: [{
                label: 'Total Sales',
                data: [3000, 4500, 6000, 3500, 7000, 5500],
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            }]
        };

        var topSellingProductsData = {
            labels: ['Product A', 'Product B', 'Product C', 'Product D'],
            datasets: [{
                label: 'Units Sold',
                data: [100, 80, 120, 90],
                backgroundColor: ['rgba(255, 99, 132, 0.2)', 'rgba(54, 162, 235, 0.2)', 'rgba(255, 206, 86, 0.2)', 'rgba(75, 192, 192, 0.2)'],
                borderColor: ['rgba(255, 99, 132, 1)', 'rgba(54, 162, 235, 1)', 'rgba(255, 206, 86, 1)', 'rgba(75, 192, 192, 1)'],
                borderWidth: 1
            }]
        };

        var salesByCategoryData = {
            labels: ['Category 1', 'Category 2', 'Category 3'],
            datasets: [{
                data: [40, 30, 50],
                backgroundColor: ['rgba(255, 99, 132, 0.5)', 'rgba(54, 162, 235, 0.5)', 'rgba(255, 206, 86, 0.5)'],
                borderColor: ['rgba(255, 99, 132, 1)', 'rgba(54, 162, 235, 1)', 'rgba(255, 206, 86, 1)'],
                borderWidth: 1
            }]
        };

        var revenueTrendsData = {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
            datasets: [{
                label: 'Revenue',
                data: [5000, 6500, 7200, 4800, 7800, 6000],
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            }]
        };

        var orderStatusData = {
            labels: ['Processing', 'Shipped', 'Delivered'],
            datasets: [{
                data: [20, 50, 30],
                backgroundColor: ['rgba(255, 99, 132, 0.5)', 'rgba(54, 162, 235, 0.5)', 'rgba(255, 206, 86, 0.5)'],
                borderColor: ['rgba(255, 99, 132, 1)', 'rgba(54, 162, 235, 1)', 'rgba(255, 206, 86, 1)'],
                borderWidth: 1
            }]
        };

        var customerAcquisitionData = {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
            datasets: [{
                label: 'New Customers',
                data: [10, 15, 18, 12, 20, 16],
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            }]
        };


        // AJAX Usage



        // Chart.js configurations for each chart
        var chartOptions = {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        };

        new Chart(document.getElementById('salesChart').getContext('2d'), {
            type: 'line',
            data: salesData,
            options: chartOptions
        });

        new Chart(document.getElementById('topSellingProductsChart').getContext('2d'), {
            type: 'bar',
            data: topSellingProductsData,
            options: chartOptions
        });

        new Chart(document.getElementById('salesByCategoryChart').getContext('2d'), {
            type: 'doughnut',
            data: salesByCategoryData,
            options: chartOptions
        });

        new Chart(document.getElementById('revenueTrendsChart').getContext('2d'), {
            type: 'line',
            data: revenueTrendsData,
            options: chartOptions
        });

        new Chart(document.getElementById('orderStatusChart').getContext('2d'), {
            type: 'doughnut',
            data: orderStatusData,
            options: chartOptions
        });

        new Chart(document.getElementById('customerAcquisitionChart').getContext('2d'), {
            type: 'bar',
            data: customerAcquisitionData,
            options: chartOptions
        });
    </script>


    <script src="<?php echo e(asset('assets/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/bootstrap.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/ajax.js')); ?>"></script>

    <script>

        $(document).ready(function(){
            getTopSolded();
            function getTopSolded()
            {
                $.ajax({
                    url: window.location.origin+'/api/top-sold',
                    method: 'get',
                    success: function(res){

                        
                        console.log(res);
                    },
                    error: function(er){
                        console.log(er);
                    }
                });
            }
        });
    </script>

</body>

</html>
<?php /**PATH C:\wamp64\www\eternitytest\resources\views/pages/dashboard.blade.php ENDPATH**/ ?>