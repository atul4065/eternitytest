For only understanding with backend , I just make the API's to use with.
## Basic Requirement:
>> Composer install.
>> Connect to mysqli with dbname.
>> run migrations (php artisan migrate)  from terminal.
>> After that you need to seed demo data to tables (php artisan db:seed --class=DemoEcommerceRecordSeeder)
>> Finally data is inserted to tables successfully.

## Authentication
>> Package used to authenticate user(SANCTUM)
TO create user you need to execute registeration api to create user.
After creation user , you need to hit login api to authenticate.

After Successfull login you are authenticated and authorized to hit graph apis.

## For graph
>> After seeding the data, we are trigerring the All graph api to test data
>> The all graph Api's are secure with middleware to prevent from unauthenticated user.


## Controllers
>> For Manuall Operation, I have added minimal methods to trigger few funcationlity like Create Products, Order Product and update order status.
>> Controller Structure is contains  statements in more readable form and enhance the undertsanding and low the difficulty to read and scalable more.
>> On the other hand graph controller is directly triggered with frontface execution which is write to show , it is not good approach. 

## Hope develper understand the Organize. Mainly The Repository pattern is more comfortable and used  for enterprise level softwares. 
