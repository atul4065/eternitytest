<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Ramsey\Uuid\Uuid;

class Order extends Model
{
    use HasFactory, SoftDeletes;

    const PROCESSING = "processing";

    const SHIPPED = "shipped";

    const DELIVERED = "delivered";

    const CANCELLED  = "cancelled";

    protected $table = "orders";
    protected $fillable = ["uuid", "product_id", "selling_price", "movement_status", "ordered_quantity"];

    protected static function booted()
    {
        static::creating(function (Order $order) {
        $order->uuid = Uuid::uuid4()->toString();
        });
    }
}
