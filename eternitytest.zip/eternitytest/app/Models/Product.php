<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Ramsey\Uuid\Uuid;

class Product extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = "products";
    protected $fillable = ['uuid', 'slug', 'title', 'in_stock', 'category_id', 'description', 'actual_price'];

    protected static function booted()
    {
        static::creating(function (Product $product) {
            $product->uuid = Uuid::uuid4()->toString();
        });
    }
}
