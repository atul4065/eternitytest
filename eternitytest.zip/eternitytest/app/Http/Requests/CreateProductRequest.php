<?php

namespace App\Http\Requests;

use App\Models\Product;
use Illuminate\Support\Str;

class CreateProductRequest extends Request
{

    public function fields(): array
    {
        return [
            "title",
            "description",
            "actual_price",
            "category_id"
        ];
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            "title" => "required",
            "description" => "nullable",
            "actual_price" => "required|numeric|min:1",
            "category_id" => "required|exists:categories,id"
        ];
    }

    public function formatData(array $data)
    {
        $slug = Str::slug($data['title']);
        $data['slug'] = $slug;

        $checkExistance = Product::where('slug','=', $slug)->exists();

        if($checkExistance){
            $data['slug'] = $slug.'-'.Str::uuid();
        }

        return $data;
    }
}
