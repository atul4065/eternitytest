<?php

namespace App\Http\Requests\Orders;

use App\Http\Requests\Request;

class OrderUpdateRequest extends Request
{


    public function fields(): array
    {
        return [
            "movement_status"
        ];
    }


    public function rules()
    {
        return [
            "movement_status" => "required|string|in:cancelled,shipped,delivered"
        ];
    }

    public function formatData(array $data)
    {
        return $data;
    }
}
