<?php

namespace App\Http\Requests\Orders;

use App\Http\Requests\Request;
use App\Models\Order;

class BuyItemRequest extends Request
{

    public function fields(): array
    {
        return [
            "product_id",
            "selling_price",
            "ordered_quantity"
        ];
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            "product_id" => "required|numeric|exists:products,id",
            "selling_price" => "required|numeric",
            "ordered_quantity" => "required|numeric|min:1"
        ];
    }

    public function formatData(array $data)
    {
        $data['movement_status'] = Order::PROCESSING;
        return $data;
    }
}
