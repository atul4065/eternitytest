<?php

namespace App\Http\Requests;


class LoginUserRequest extends Request
{
   public function fields(): array
   {
    return [
        'email',
        'password'
    ];
   }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            'email'=> 'required|email|exists:users,email',
            'password' => 'required|min:6'
        ];
    }

    public function formatData(array $data)
    {
        return $data;
    }
}
