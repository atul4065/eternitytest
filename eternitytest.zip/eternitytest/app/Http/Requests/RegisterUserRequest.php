<?php

namespace App\Http\Requests;


class RegisterUserRequest extends Request
{
   public function fields(): array
   {
    return [
        'name',
        'email',
        'password'
    ];
   }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            'name' => 'required',
            'email'=> 'required|email|unique:users,email',
            'password' => 'required|min:6'
        ];
    }

    public function formatData(array $data)
    {
        $data['password'] = bcrypt($data['password']);
        return $data;
    }
}
