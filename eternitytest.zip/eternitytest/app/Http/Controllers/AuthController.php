<?php

namespace App\Http\Controllers;

use App\Http\Requests\LoginUserRequest;
use App\Http\Requests\RegisterUserRequest;
use App\Http\Resources\AuthResource;
use App\Repository\Users\UserRepository;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{

    public $users;

    public function __construct(UserRepository $users)
    {
        $this->users = $users;
    }
    public function register(RegisterUserRequest $request)
    {
        $data = $request->getAndFormatData();

        $user = $this->users->create($data);

        return new AuthResource($user);
    }

    public function  login(LoginUserRequest $request)
    {
        $data = $request->getAndFormatData();

        if(Auth::attempt($data)) {
            $user = Auth::user();
            return response()->json([
                    'token' => $user->createToken('eternitytest')->plainTextToken,
                    'type' => 'bearer',
            ]);
        }

        return response()->json([
            'message' => 'Invalid credentials',
        ], 401);
    }

    public function me()
    {
        $user = Auth::user();

        return AuthResource::make($user);
    }

    public function logout()
    {
        Auth::user()->tokens()->delete();
        return response()->json([
            'message' => 'Successfully logged out',
        ]);
    }
}
