<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Order;
use App\Models\Product;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class GraphController extends Controller
{

    public $organizedYears = [
        1 => "jan",
        2 => "feb",
        3 => "mar",
        4 => "apr",
        5 => "may",
        6 => "jun",
        7 => "jul",
        8 => "aug",
        9 => "sept",
        10 => "oct",
        11 => "nov",
        12 => "dec"
    ];

    public function getCategorizedSales()
    {
        $sales = Category::join('products', 'products.category_id', '=', 'categories.id')
        ->join('orders', 'products.id', '=', 'orders.product_id')
        ->where('orders.movement_status', Order::DELIVERED)
        ->groupBy('categories.name')
        ->select('categories.name', DB::raw('SUM(orders.ordered_quantity) as sold_quantity'))
        ->orderBy('sold_quantity', 'desc')
        ->get();

        return response()->json(['data' => $sales]);
    }

    public function getTotalSales()
    {
        $hippedSales = Order::select(DB::raw('SUM(selling_price) as total_amount'), DB::raw('MONTHNAME(created_at) as month'))
        ->groupBy(DB::raw('MONTHNAME(created_at)'))
        ->where('movement_status', Order::DELIVERED)
        ->whereYear('created_at', '2024')
        ->get();

        return response()->json(['data' => $hippedSales]);

    }

    public function getTopSoldedProducts()
    {
    $topSolds = Product::join('orders', 'products.id', '=', 'orders.product_id')
    ->where('orders.movement_status', Order::DELIVERED)
    ->groupBy('orders.product_id')
    ->select('products.title as title', DB::raw('SUM(orders.ordered_quantity) as solded'))
    ->get();

    return response()->json(['data' => $topSolds]);
    }

    public function getOrderStatuses()
    {
        $statues = Order::groupBy('movement_status')->select('movement_status', DB::raw('count(movement_status) as count'))->get();

        return response()->json(["data" => $statues]);
    }

    public function getRegisteredUserViaMonths()
    {
        $users = User::select(DB::raw('COUNT(*) as count'), DB::raw('MONTHNAME(created_at) as month'))
        ->whereYear('created_at', '2024')
        ->groupBy(DB::raw('MONTHNAME(created_at)'))
        ->get();

        return response()->json(['data' =>$users]);
    }
}
