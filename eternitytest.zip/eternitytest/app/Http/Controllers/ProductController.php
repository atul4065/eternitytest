<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateProductRequest;
use App\Http\Resources\ProductResource;
use App\Repository\Products\ProductRepository;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public $product;

    public function __construct(ProductRepository $product)
    {
        $this->product = $product;
    }

    public function create(CreateProductRequest $request)
    {
        $data =  $request->getAndFormatData();

        $product = $this->product->create($data);

        return ProductResource::make($product);
    }
}
