<?php

namespace App\Http\Controllers;

use App\Http\Requests\Orders\BuyItemRequest;
use App\Http\Requests\Orders\OrderUpdateRequest;
use App\Http\Resources\OrderResource;
use App\Repository\Products\ProductRepository;
use Illuminate\Http\Request;

class ProductOrderController extends Controller
{
    public $order;
    public function __construct(ProductRepository $order)
    {
        $this->order = $order;
    }

    public function buyItem(BuyItemRequest $request)
    {
        $data = $request->getAndFormatData();

        $orderNow = $this->order->buyItem($data);

        return OrderResource::make($orderNow);
    }

    public function updateStatus($id, OrderUpdateRequest $request)
    {
        $data = $request->getAndFormatData();

        $updateStatus = $this->order->orderMovementUpdateAndTrack($id, $data);

        return response()->json($updateStatus);
    }
}
