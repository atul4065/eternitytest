<?php

namespace App\Repository\Users;

class UserRepository
{
    public function create(array $data)
    {
        return (new UserCreater())->create($data);
    }
}
