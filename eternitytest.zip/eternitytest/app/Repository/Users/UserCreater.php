<?php

namespace App\Repository\Users;

use App\Models\User;
use App\Repository\Interfaces\CreaterInterface;

class  UserCreater implements CreaterInterface
{
    public function create(array $data)
    {
        $create = User::create($data);

        return $create;
    }
}
