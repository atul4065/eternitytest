<?php

namespace App\Repository\Interfaces;

interface UpdatorInterface
{
    public function update($id, array $data);
}
