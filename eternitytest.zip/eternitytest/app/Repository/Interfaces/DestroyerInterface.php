<?php

namespace App\Repository\Interfaces;

interface DestroyerInterface{
    public function destroy($id);
}
