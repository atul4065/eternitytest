<?php

namespace App\Repository\Interfaces;

interface CreaterInterface{
    public function create(array $data);
}
