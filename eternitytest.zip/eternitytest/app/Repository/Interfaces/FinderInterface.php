<?php

namespace App\Repository\Interfaces;

interface FinderInterface
{
    public function find($id);
}
