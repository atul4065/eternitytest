<?php

namespace App\Repository\Products\Orders;

use App\Models\Order;
use App\Repository\Interfaces\UpdatorInterface;

class OrderMovementUpdator implements UpdatorInterface
{

    public function update($id, $data)
    {
       $update = Order::find($id)->update($data);

       return $update;
    }
}
