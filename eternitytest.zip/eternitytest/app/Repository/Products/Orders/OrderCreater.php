<?php

namespace App\Repository\Products\Orders;

use App\Models\Order;
use App\Repository\Interfaces\CreaterInterface;

class OrderCreater implements CreaterInterface
{
    public function create(array $data)
    {
        $create = Order::create($data);

        return $create;
    }
}
