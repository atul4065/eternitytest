<?php

namespace App\Repository\Products;

use App\Repository\Products\Orders\OrderCreater;
use App\Repository\Products\Orders\OrderMovementUpdator;

class ProductRepository
{

    public function create(array $data)
    {
        return (new ProductCreater())->create($data);
    }

    /**
     * Orders
     */

     public function buyItem(array $data)
     {
        return (new OrderCreater())->create($data);
     }

     public function orderMovementUpdateAndTrack($id, $data)
     {
        return (new OrderMovementUpdator())->update($id, $data);
     }
}
