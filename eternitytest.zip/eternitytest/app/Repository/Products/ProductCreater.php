<?php

namespace App\Repository\Products;

use App\Models\Product;
use App\Repository\Interfaces\CreaterInterface;

class ProductCreater implements CreaterInterface
{

    public function create(array $data)
    {
        $create = Product::create($data);

        return $create;
    }
}
