<?php

namespace Database\Seeders;

use App\Models\Category;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class CategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Category::firstOrCreate(['name'=> "Shoes"]);
        Category::firstOrCreate(['name'=> "Kitchen Appliances"]);
        Category::firstOrCreate(['name'=> "Kids Accessories"]);
        Category::firstOrCreate(['name'=> "Clothings"]);
    }
}
