<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\Order;
use App\Models\Product;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DemoEcommerceRecordSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $cat1 = Category::firstOrCreate(['name'=> "Shoes"]);
        $cat2 = Category::firstOrCreate(['name'=> "Kitchen Appliances"]);
        $cat3 = Category::firstOrCreate(['name'=> "Kids Accessories"]);
        $cat4 = Category::firstOrCreate(['name'=> "Clothings"]);

        $product1 = Product::firstOrCreate(['slug' => fake()->slug(),
         'title' => fake()->name(),
         'in_stock' =>  mt_rand(10, 100),
         'category_id' => $cat1->id,
         'description' => fake()->text(),
         'actual_price' => mt_rand(100, 500)]);

         $product2 = Product::firstOrCreate(['slug' => fake()->slug(),
         'title' => fake()->name(),
         'in_stock' =>  mt_rand(10, 100),
         'category_id' => $cat2->id,
         'description' => fake()->text(),
         'actual_price' => mt_rand(100, 500)]);

         $product3 = Product::firstOrCreate(['slug' => fake()->slug(),
         'title' => fake()->name(),
         'in_stock' =>  mt_rand(10, 100),
         'category_id' => $cat3->id,
         'description' => fake()->text(),
         'actual_price' => mt_rand(100, 500)]);

         $product4 = Product::firstOrCreate(['slug' => fake()->slug(),
         'title' => fake()->name(),
         'in_stock' =>  mt_rand(10, 100),
         'category_id' => $cat1->id,
         'description' => fake()->text(),
         'actual_price' => mt_rand(100, 500)]);

         $product5 = Product::firstOrCreate(['slug' => fake()->slug(),
         'title' => fake()->name(),
         'in_stock' =>  mt_rand(10, 100),
         'category_id' => $cat1->id,
         'description' => fake()->text(),
         'actual_price' => mt_rand(100, 500)]);
         $product6 = Product::firstOrCreate(['slug' => fake()->slug(),
         'title' => fake()->name(),
         'in_stock' =>  mt_rand(10, 100),
         'category_id' => $cat1->id,
         'description' => fake()->text(),
         'actual_price' => mt_rand(100, 500)]);

         $order1 = Order::create(['product_id'=> $product1->id,
         'movement_status' => 'shipped',
         'ordered_quantity' => 2,
         'selling_price' => $product1->actual_price]);

         $order2 = Order::create(['product_id'=> $product2->id,
         'movement_status' => 'processing',
         'ordered_quantity' => 2,
         'selling_price' => $product2->actual_price]);

         $order3 = Order::create(['product_id'=> $product3->id,
         'movement_status' => 'delivered',
         'ordered_quantity' => 2,
         'selling_price' => $product3->actual_price]);

         $order4 = Order::create(['product_id'=> $product4->id,
         'movement_status' => 'delivered',
         'ordered_quantity' => 1,
         'selling_price' => $product4->actual_price]);
    }
}
